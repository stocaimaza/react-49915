import Padre from "../Padre/Padre"

const Abuelo = () => {
  return (
    <div>
        <Padre />
    </div>
  )
}

export default Abuelo