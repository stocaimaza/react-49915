import { useEffect } from "react";

const Escuchadores = () => {

    window.addEventListener("resize", ()=> {
        console.log("Cambiaste la pantalla!");
    })

    //Lo ideal seria hacer algo asi: 

    useEffect(()=> {
        function click() {
            console.log("click")
        }

        return () => {
            window.removeEventListener("click", click)
        }

    }, [])


  return (
    <div>Escuchadores</div>
  )
}

export default Escuchadores