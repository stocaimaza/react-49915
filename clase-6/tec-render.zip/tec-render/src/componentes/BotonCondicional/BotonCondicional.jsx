//Ejercicio de Renderizado condicional aplicando un Login. 

import { useState } from "react";


const BotonCondicional = () => {
    const [verificado, setVerificado] = useState(false);

    //Creo los estado para el usuario y el pass: 
    const [usuario, setUsuario] = useState("");
    const [pass, setPass] = useState("");

    //Funciones: 

    const habilitarUsuario = (e) => {
        e.preventDefault();

        //Implemento mi lógica de validación: 
        if (usuario === "Tinki" && pass === "Winki") {
            setVerificado(true);
        } else {
            setUsuario("Vete Ladrón!!");
            setPass("Rata de dos patas!");
        }

    }

    return (
        <div>
            {
                verificado ? (<button onClick={()=> setVerificado(false)}>Cerrar Sesión</button>) : (
                    <form onSubmit={habilitarUsuario}>
                        <label htmlFor=""> Usuario </label>
                        <input type="text" onChange={(e) => setUsuario(e.target.value)} value={usuario} />
                        <br /><br />

                        <label htmlFor=""> Password </label>
                        <input type="text" onChange={(e) => setPass(e.target.value)} value={pass} />
                        <br /><br />

                        <button type="submit"> Iniciar Sesión </button>
                    </form>
                )
            }
        </div>
    )
}

export default BotonCondicional