import React from 'react'

const Celulares = () => {
  return (
    <div>Celulares</div>
  )
}

export default Celulares