export const sumoTodo = (a, b) => a + b;
export const restoTodo = (a, b) => a - b;

//Tambien si queres evitar colocar la palabrita "export" podes hacerlo al final: 

//export {sumoTodo, restoTodo};