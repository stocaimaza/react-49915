//Aprendimos en estas clases que pdoemos enviar información entre componentes a traves de las props.  Pero estas se envian de forma unidireccional de un componente padre a un componente hijo. 
//En aplicaciones grandes con muchas capas de componentes esto se convierte en una tarea tediosa. 

//EJEMPLO: "HERENCIA FAMILIAR". 

//Para solucionar esto React presenta una nueva herramienta llamada "Contexto".

//En el contexto podemos almacenar datos o funciones que esten disponibles en toda la app, sin necesidad de pasar por todas las jerarquias de componentes en nuestra aplicación.

// El contexto trabaja con dos partes principales: el proveedor y el consumidor. 

//El provider es un componente que proporciona los datos que vamos a compartir y el Consumer es quien utiliza los datos proporcionados por el Provider. 

import Abuelo from "./componentes/Abuelo/Abuelo"
import { Contexto } from "./context/context";


const App = () => {

  const herencia = {
    efectivo: 10000000000, 
    propiedades: 10,
    vehiculos: 20
  }

  return (
    <div>
      {/* <Abuelo herencia={herencia}/> */}
      <Contexto.Provider value={herencia}>
        <Abuelo/>
      </Contexto.Provider>
    </div>
  )
}

export default App