import Nieto from "../Nieto/Nieto"

const Padre = ({herencia}) => {
  return (
    <div>
        <Nieto herencia = {herencia} />
    </div>
  )
}

export default Padre