//1) Return Temprano: 
//Esta técnica la usamos en JS y evitamos colocar el ELSE. 

//Funcion booleana que me dice si es fin de semana: 

function esFinde(dia) {
    if(dia === "sabado" || dia === "domingo") {
        return true; 
    } else {
        return false;
    }
}

//Peeeeeero si aplico el return temprano: 

function esFinDeSemana(dia) {
    if(dia === "sabado" || dia === "domingo") {
        return true;
    }
    return false; 
}

const TecnicaUno = ({nombre}) => {
  if(nombre === "Samuel") {
    return <h1>Hola Administrador!</h1>
  }
  return <h2>Hola {nombre} </h2>
}

export default TecnicaUno