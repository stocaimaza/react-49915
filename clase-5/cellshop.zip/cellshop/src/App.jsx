/*

SPA = Single Page Application.

React Router = es una librería de enrutamiento. 
Nos permite navegar entre componentes sin tener que recargar la aplicación. 

¿Cómo la usamos?

//1) Instalamos: npm install react-router-dom
//2) Importar en nuestra App algunos componente de la libreria React Router: 
BrowserRouter, Route, Routes.
BrowserRouter: es un componente que envuelve nuestra aplicació y habilita la navegación entre componentes. 
Routes: define la rutas de navegación. 
Route: define una ruta en particular.  

*/

import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./componentes/Home/Home";
import Computadoras from "./componentes/Computadoras/Computadoras";
import Sillas from "./componentes/Sillas/Sillas";
import Celulares from "./componentes/Celulares/Celulares";
import Menu from "./componentes/Menu/Menu";

const App = () => {
  return (
    <div>
      <BrowserRouter>
        <Menu/>
        <Routes>
          <Route path="/computadoras" element={<Computadoras/>}/>
          <Route path="/sillas/:id" element={<Sillas/>} />
          <Route path="/celulares"  element={<Celulares/>} />
          <Route path="/" element={<Home/>} />
          <Route path="*" element={<h2>Sitio en Construccion</h2>} />
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App


/*
<h1>Etiquetas de Enlaces </h1>
<h2>Enlace Absoluto</h2>
<a href="https://infobae.com" target='_blank'> Infobae </a>
<h2>Enlaces Relativos </h2>
<a href=""> Cualquier cosa </a>
*/
