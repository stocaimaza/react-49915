import { sumoTodo } from "./operaciones.js";

console.log(sumoTodo(150,50));