import { useState } from "react";

const Formulario = () => {
    const [nombre, setNombre] = useState("");
    const [apellido, setApellido] = useState("");
    const [email, setEmail] = useState(""); 

    //Creamos una función manejadora del formulario: 
    const manejadorFormulario = (e) => {
        e.preventDefault();

        const nuevoCliente = {nombre, apellido, email}; 
        console.log(nuevoCliente);

        //Limpiamos los input: 

        setNombre("");
        setApellido("");
        setEmail("");
    }

  return (
    <form onSubmit={manejadorFormulario}>
        <h2>Datos de Contacto</h2>

        <label htmlFor=""> Nombre </label>
        <input type="text" onChange={(e)=> setNombre(e.target.value)} />
        <br /><br />

        <label htmlFor=""> Apellido </label>
        <input type="text" onChange={(e)=> setApellido(e.target.value)} />
        <br /><br />

        <label htmlFor=""> Correo Electrónico </label>
        <input type="email" onChange={(e)=> setEmail(e.target.value)}/>
        <br /><br />

        <button type="submit"> Enviar </button>


    </form>
  )
}

export default Formulario