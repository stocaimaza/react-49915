//3)Operador ternario: 


const TecnicaTres = ({booleano}) => {
  return (
    <div>
        {
            booleano ? <h3> Acceso Permitido </h3> : <h4>Acceso denegado!  Vete ladron malvado!!</h4>
        }
    </div>
  )
}

export default TecnicaTres