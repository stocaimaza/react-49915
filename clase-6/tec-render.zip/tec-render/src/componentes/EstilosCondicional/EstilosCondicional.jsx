import React from 'react';
import './EstilosCondicional.css';

//Podemos usar los estilos condicionales en línea y también podemos usar clases. 

const EstilosCondicional = ({booleano, clase}) => {
  return (
    <div>
        <h2 style={{color: booleano ? "red" : "green"}}> Estilos Condicional </h2>

        <h2 className={booleano ? "amarillo" : "azul"}>Trabajando con Clases</h2>

        <h2 className={booleano && "azul"}>Ejemplo usando el operador &&</h2>

        <h2 className={clase}>Recibo una clase por props</h2>
    </div>
  )
}

export default EstilosCondicional