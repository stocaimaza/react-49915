//UTILIZANDO PROPS: 

// import React from 'react'

// const Nieto = ({herencia}) => {
//   return (
//     <div>
//         <p>Mi herencia es de: {herencia.efectivo} </p>
//         <p>Tengo estas casas: {herencia.propiedades} </p>
//         <p>Y estos vehiculos: {herencia.vehiculos} </p>
//     </div>
//   )
// }

// export default Nieto


//UTILIZANDO EL CONSUMER: 

// import React from 'react';
// import { Contexto } from '../../context/context';

//Para poder acceder a la información utilizamos un función de renderizado: 
// const Nieto = () => {
//     return (
//         <Contexto.Consumer>
//             {
//                 (herencia) => (
//                     <div>
//                         <p>Mi herencia es de: {herencia.efectivo} </p>
//                         <p>Tengo estas casas: {herencia.propiedades} </p>
//                         <p>Y estos vehiculos: {herencia.vehiculos} </p>
//                         <p> UTILIZANDO EL CONSUMER </p>
//                     </div>
//                 )
//             }

//         </Contexto.Consumer>
//     )
// }

// export default Nieto


//UTILIZANDO UN HOOK:  En lugar de usar el consumer y una función de renderizado yo puedo utilizar un Hook llamado useContext. 

//1) Importamos el Contexto. 
//2) Importamos el hook useContext. 
//3) Creamos una variable que almacene el valor del contexto. LLamo al hook y le paso el contexto como argumento. 


import { Contexto } from '../../context/context';
import { useContext } from 'react';

const Nieto = () => {
    const herencia = useContext(Contexto);

  return (
    <div>
        <p> Tengo este dinero!! : {herencia.efectivo} </p>
        <p> Choque todos estos autos: {herencia.vehiculos} </p>
        <p> Y estas casas vendi: {herencia.propiedades} </p>
        <strong>Usando el useContext!</strong>
    </div>
  )
}

export default Nieto